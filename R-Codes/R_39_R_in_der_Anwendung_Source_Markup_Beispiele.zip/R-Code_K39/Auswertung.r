### ---------------------------------------------------------
### Kaptiel 39.1: R-Code in mehrere Dateien teilen - source()
### Auswertung.R
### ---------------------------------------------------------

print(bmi(gewicht, groesse))
