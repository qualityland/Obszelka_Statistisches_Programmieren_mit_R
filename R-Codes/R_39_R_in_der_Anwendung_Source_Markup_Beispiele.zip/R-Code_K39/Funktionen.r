### ---------------------------------------------------------
### Kaptiel 39.1: R-Code in mehrere Dateien teilen - source()
### Funktion.R
### ---------------------------------------------------------

bmi <- function(gewicht, groesse) {
  return(gewicht / (groesse / 100) ^ 2)
}
